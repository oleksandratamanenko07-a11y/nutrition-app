-- Nutrition Tracker: схема базы данных (Supabase / PostgreSQL)
-- Запускается один раз в Supabase: SQL Editor -> New query -> Run

create extension if not exists pg_trgm;

-- Пользователи (идентификатор берётся из Telegram)
create table if not exists profiles (
  telegram_id     bigint primary key,
  first_name      text,
  username        text,
  sex             text check (sex in ('male','female')),
  birth_year      int  check (birth_year between 1900 and 2100),
  height_cm       numeric(5,1),
  weight_kg       numeric(5,2),
  target_weight_kg numeric(5,2),
  activity_level  text check (activity_level in ('sedentary','light','moderate','high','very_high')),
  goal            text check (goal in ('lose','maintain','gain')),
  kcal_goal       int,
  protein_goal_g  int,
  fat_goal_g      int,
  carbs_goal_g    int,
  water_goal_ml   int default 2000,
  theme           text default 'auto',
  language        text not null default 'uk' check (language in ('uk','pl','en','ru')),
  onboarded       boolean default false,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- Продукты (все значения на 100 г). null = данных нет, выдуманных значений не храним.
create table if not exists foods (
  id            uuid primary key default gen_random_uuid(),
  owner_id      bigint references profiles(telegram_id) on delete cascade, -- null = общий кэш
  barcode       text,
  name          text not null,
  brand         text,
  country       text,
  image_url     text,
  kcal_100      numeric(7,2) check (kcal_100 >= 0),
  protein_100   numeric(7,2) check (protein_100 >= 0),
  fat_100       numeric(7,2) check (fat_100 >= 0),
  carbs_100     numeric(7,2) check (carbs_100 >= 0),
  source        text not null default 'manual' check (source in ('openfoodfacts','manual','recipe')),
  is_favorite   boolean default false,
  last_used_at  timestamptz,
  created_at    timestamptz default now()
);
create index if not exists foods_owner_barcode_idx on foods(owner_id, barcode);
create index if not exists foods_name_trgm_idx on foods using gin (name gin_trgm_ops);

-- Рецепты
create table if not exists recipes (
  id         uuid primary key default gen_random_uuid(),
  owner_id   bigint not null references profiles(telegram_id) on delete cascade,
  name       text not null,
  total_weight_g numeric(8,2), -- вес готового блюда
  food_id    uuid references foods(id) on delete set null, -- рецепт как продукт на 100 г
  created_at timestamptz default now()
);

create table if not exists recipe_ingredients (
  id        uuid primary key default gen_random_uuid(),
  recipe_id uuid not null references recipes(id) on delete cascade,
  food_id   uuid not null references foods(id),
  amount_g  numeric(8,2) not null check (amount_g > 0)
);

-- Дневник питания. Значения на 100 г копируются в запись,
-- чтобы история не менялась при исправлении продукта.
create table if not exists diary_entries (
  id          uuid primary key default gen_random_uuid(),
  owner_id    bigint not null references profiles(telegram_id) on delete cascade,
  entry_date  date not null,
  meal        text not null check (meal in ('breakfast','lunch','dinner','snack')),
  food_id     uuid references foods(id) on delete set null,
  name        text not null,
  amount_g    numeric(8,2) not null check (amount_g > 0),
  kcal_100    numeric(7,2) not null,
  protein_100 numeric(7,2) not null,
  fat_100     numeric(7,2) not null,
  carbs_100   numeric(7,2) not null,
  created_at  timestamptz default now()
);
create index if not exists diary_owner_date_idx on diary_entries(owner_id, entry_date);

create table if not exists water_logs (
  id        uuid primary key default gen_random_uuid(),
  owner_id  bigint not null references profiles(telegram_id) on delete cascade,
  log_date  date not null,
  amount_ml int not null check (amount_ml <> 0),
  created_at timestamptz default now()
);
create index if not exists water_owner_date_idx on water_logs(owner_id, log_date);

create table if not exists weight_logs (
  id        uuid primary key default gen_random_uuid(),
  owner_id  bigint not null references profiles(telegram_id) on delete cascade,
  log_date  date not null,
  weight_kg numeric(5,2) not null check (weight_kg > 0),
  unique (owner_id, log_date)
);

-- Безопасность: RLS включён, политик для клиента нет.
-- Доступ к данным только через наш сервер (Vercel /api) с service_role ключом
-- после проверки подписи Telegram initData.
alter table profiles          enable row level security;
alter table foods             enable row level security;
alter table recipes           enable row level security;
alter table recipe_ingredients enable row level security;
alter table diary_entries     enable row level security;
alter table water_logs        enable row level security;
alter table weight_logs       enable row level security;
