// Самоперевірка: розрахунки КБЖУ та перевірка підпису Telegram.
// Запуск: node scripts/selftest.mjs
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { bmr, computeGoals, portion, sum, round1 } from '../src/lib/calc.ts';
import { verifyInitData } from '../api/_lib/auth.ts';

// --- Розрахунки ---
assert.equal(bmr('female', 60, 165, 30), 1320.25);
assert.equal(bmr('male', 80, 180, 30), 1780);

const g = computeGoals({ sex: 'female', age: 30, heightCm: 165, weightKg: 60, activity: 'sedentary', goal: 'maintain' });
assert.equal(g.kcal, 1584); // 1320.25 * 1.2 = 1584.3
assert.equal(g.protein, 96);
const kcalFromMacros = g.protein * 4 + g.fat * 9 + g.carbs * 4;
assert.ok(Math.abs(kcalFromMacros - g.kcal) <= 6, `макроси дають ${kcalFromMacros} ккал замість ${g.kcal}`);

const lose = computeGoals({ sex: 'female', age: 50, heightCm: 150, weightKg: 45, activity: 'sedentary', goal: 'lose' });
assert.ok(lose.kcal >= 1200, 'нижня межа калорій');

// Порції: 52.5 ккал/100 г × 150 г = 78.75
const p = portion({ kcal: 52.5, protein: 0.3, fat: 0.2, carbs: 14 }, 150);
assert.equal(p.kcal, 78.75);
assert.equal(p.protein, 0.45);
assert.equal(p.carbs, 21);
assert.equal(round1(p.kcal), 78.8);

// Класична пастка float: 0.1 + 0.2 повинно давати рівно 0.3
const s = sum([
  { kcal: 0.1, protein: 0, fat: 0, carbs: 0 },
  { kcal: 0.2, protein: 0, fat: 0, carbs: 0 },
]);
assert.equal(round1(s.kcal), 0.3);

// --- Підпис Telegram ---
const botToken = '123456:TEST-TOKEN';
function sign(fields) {
  const params = new URLSearchParams(fields);
  const dcs = [...params.entries()].sort((a, b) => (a[0] < b[0] ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  params.set('hash', crypto.createHmac('sha256', secret).update(dcs).digest('hex'));
  return params.toString();
}
const now = Math.floor(Date.now() / 1000);
const user = JSON.stringify({ id: 42, first_name: 'Тест', username: 'tester' });

const good = sign({ auth_date: String(now), query_id: 'AAA', user });
assert.equal(verifyInitData(good, botToken)?.id, 42, 'вірний підпис має проходити');

assert.equal(verifyInitData(good, 'інший:токен'), null, 'інший токен бота має відхилятись');
assert.equal(verifyInitData(good.replace('tester', 'hacker'), botToken), null, 'підроблені дані мають відхилятись');
assert.equal(verifyInitData(good.replace(/hash=[0-9a-f]+/, 'hash=00'), botToken), null, 'неправильний hash');
assert.equal(verifyInitData('auth_date=1&user=%7B%7D', botToken), null, 'без hash');

const old = sign({ auth_date: String(now - 3 * 24 * 3600), user });
assert.equal(verifyInitData(old, botToken), null, 'застарілі дані мають відхилятись');

console.log('OK: усі перевірки пройдені');
